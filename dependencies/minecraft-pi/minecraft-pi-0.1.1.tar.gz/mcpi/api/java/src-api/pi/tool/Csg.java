package pi.tool;

/**
 * Constructive Solid Geometry tool
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
class Csg {

}
